//
// Created by Karl on 02.06.2026.
//

#include "Stm32WlCubeHal.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

// RadioLib Konstanten (da kein Arduino vorhanden)
#ifndef INPUT
#define INPUT 0
#endif
#ifndef OUTPUT
#define OUTPUT 1
#endif
#ifndef LOW
#define LOW 0
#endif
#ifndef HIGH
#define HIGH 1
#endif
#ifndef RISING
#define RISING 0
#endif
#ifndef FALLING
#define FALLING 1
#endif

Stm32WlCubeHal::Stm32WlCubeHal()
    : RadioLibHal(INPUT, OUTPUT, LOW, HIGH, RISING, FALLING) {}

// ── GPIO ──────────────────────────────────────────────────────────────────

void Stm32WlCubeHal::pinMode(uint32_t pin, uint32_t mode) {
    if (pin >= RADIOLIB_VIRTUAL_PIN_BASE) return; // virtuelle Pins: nichts tun

    //GPIO_InitTypeDef cfg = {0};
    GPIO_InitTypeDef cfg = {
    (1u << (pin & 0x0F)),
    (mode == OUTPUT) ? GPIO_MODE_OUTPUT_PP : GPIO_MODE_INPUT,
    GPIO_NOPULL,
    GPIO_SPEED_FREQ_VERY_HIGH,
    GPIO_PIN_RESET
    };


    // Clock aktivieren je nach Port (PA=0, PB=1, PC=2)
    uint8_t port = (pin >> 4) & 0x0F;
    GPIO_TypeDef* gpioPort[] = {GPIOA, GPIOB, GPIOC};
    if (port == 0) __HAL_RCC_GPIOA_CLK_ENABLE();
    else if (port == 1) __HAL_RCC_GPIOB_CLK_ENABLE();
    else if (port == 2) __HAL_RCC_GPIOC_CLK_ENABLE();

    HAL_GPIO_Init(gpioPort[port], &cfg);
}

void Stm32WlCubeHal::digitalWrite(uint32_t pin, uint32_t value) {
    if (pin >= RADIOLIB_VIRTUAL_PIN_BASE) {
        // Virtueller Pin -> RF-Switch
        // Beim STM32WL erfolgt die Steuerung oft über GPIOs, die im CubeMX konfiguriert wurden.
        // Hier müsste die entsprechende Logik für den RAK3272 implementiert werden.
        return;
    }
    uint8_t port = (pin >> 4) & 0x0F;
    GPIO_TypeDef* gpioPort[] = {GPIOA, GPIOB, GPIOC};
    HAL_GPIO_WritePin(gpioPort[port],
                      (1u << (pin & 0x0F)),
                      value ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

uint32_t Stm32WlCubeHal::digitalRead(uint32_t pin) {
    if (pin >= RADIOLIB_VIRTUAL_PIN_BASE) return 0;
    uint8_t port = (pin >> 4) & 0x0F;
    GPIO_TypeDef* gpioPort[] = {GPIOA, GPIOB, GPIOC};
    return HAL_GPIO_ReadPin(gpioPort[port], (1u << (pin & 0x0F)));
}

// ── Interrupts ────────────────────────────────────────────────────────────

void Stm32WlCubeHal::attachInterrupt(uint32_t pin, void (*func)(void), uint32_t mode) {
    // IRQ vom SUBGHZ-Peripheral kommt über NVIC — wird durch RadioLib
    // über HAL_SUBGHZ_IRQHandler abgehandelt, nicht über GPIO-EXTI
    (void)pin; (void)func; (void)mode;
}

void Stm32WlCubeHal::detachInterrupt(uint32_t pin) {
    (void)pin;
}

// ── Timing ────────────────────────────────────────────────────────────────

void Stm32WlCubeHal::delay(RadioLibTime_t ms) {
    HAL_Delay(ms);
}

void Stm32WlCubeHal::delayMicroseconds(RadioLibTime_t us) {
    // STM32 HAL hat kein eingebautes µs-Delay — einfache Schleife oder Timer nutzen
    // Hier ein sehr grobes Delay als Platzhalter
    uint32_t start = HAL_GetTick();
    while ((HAL_GetTick() - start) < (us / 1000 + 1));
}

RadioLibTime_t Stm32WlCubeHal::millis() {
    return HAL_GetTick();
}

RadioLibTime_t Stm32WlCubeHal::micros() {
    return HAL_GetTick() * 1000UL;
}

// ── SUBGHZ-SPI (intern) ───────────────────────────────────────────────────

void Stm32WlCubeHal::spiBegin() {
    // SUBGHZ-Peripheral wird durch MX_SUBGHZ_Init() initialisiert
    // nichts weiter zu tun
}

void Stm32WlCubeHal::spiBeginTransaction() {
    _spiActive = true;
}

void Stm32WlCubeHal::spiTransfer(uint8_t* out, size_t len, uint8_t* in) {
    if (!_spiActive) return;

    // Für STM32WL SUBGHZ-Peripheral:
    // RadioLib nutzt spiTransfer für Kommandos.
    // Beim WLE5 muss man HAL_SUBGHZ_ExecGetCmd oder HAL_SUBGHZ_ExecSetCmd nutzen.
    // Da spiTransfer in RadioLib oft für "Transaction" genutzt wird,
    // ist die Implementierung hier komplexer, da RadioLib erwartet
    // dass NSS (CS) manuell gesteuert wird, was beim internen SUBGHZ-SPI nicht der Fall ist.
    
    // Dies ist eine Rumpf-Implementierung:
    if (len > 0) {
        if (in == NULL) {
             HAL_SUBGHZ_ExecSetCmd(&hsubghz, (SUBGHZ_RadioSetCmd_t)out[0], &out[1], len - 1);
        } else {
             HAL_SUBGHZ_ExecGetCmd(&hsubghz, (SUBGHZ_RadioGetCmd_t)out[0], in, len - 1);
        }
    }
}

void Stm32WlCubeHal::spiEndTransaction() {
    _spiActive = false;
}

void Stm32WlCubeHal::setRfSwitchState(bool txEnable, bool rxEnable) {
    // RAK3272 / RAK3172 RF-Switch Steuerung:
    // PA4: FE_CTRL1
    // PA5: FE_CTRL2
    // RX: PA4=HIGH, PA5=LOW
    // TX: PA4=LOW,  PA5=HIGH
    
    // GPIO Pins initialisieren falls noch nicht geschehen
    static bool pinsInit = false;
    if (!pinsInit) {
        __HAL_RCC_GPIOA_CLK_ENABLE();
        GPIO_InitTypeDef GPIO_InitStruct = {0};
        GPIO_InitStruct.Pin = GPIO_PIN_4 | GPIO_PIN_5;
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
        pinsInit = true;
    }

    if (txEnable) {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
    } else if (rxEnable) {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
    } else {
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
    }
}

void Stm32WlCubeHal::uartBegin(uint32_t baud) {
    // Direkte Register-Initialisierung für UART2 (PA2/PA3)
    // da HAL_UART_MODULE_ENABLED im Projekt fehlt
    
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_USART2_CLK_ENABLE();

    // PA2: TX, PA3: RX (AF7)
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    USART2->CR1 &= ~USART_CR1_UE;
    
    // Baudrate (PCLK1 / baud)
    uint32_t pclk = HAL_RCC_GetPCLK1Freq();
    USART2->BRR = (pclk + (baud / 2)) / baud;

    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

void Stm32WlCubeHal::uartPrint(const char* str) {
    while (*str) {
        // UART
        while (!(USART2->ISR & USART_ISR_TXE_TXFNF));
        USART2->TDR = *str;
        
        // SWD Trace (ITM)
        ITM_SendChar(*str);
        
        str++;
    }
}

void Stm32WlCubeHal::uartPrintf(const char* format, ...) {
    char buf[256];
    va_list args;
    va_start(args, format);
    vsnprintf(buf, sizeof(buf), format, args);
    va_end(args);
    uartPrint(buf);
}

void Stm32WlCubeHal::spiEnd() {}