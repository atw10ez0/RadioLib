//
// Created by Karl on 02.06.2026.
//
#pragma once
#include <RadioLib.h>
# include "stm32wlxx_hal.h"       // ST HAL aus CubeMX
#include "stm32wlxx_hal_subghz.h"


// Externe SUBGHZ-Handle-Instanz (aus MX_SUBGHZ_Init generiert)
extern SUBGHZ_HandleTypeDef hsubghz;

class Stm32WlCubeHal : public RadioLibHal {
public:
    Stm32WlCubeHal();

    // ── GPIO ──────────────────────────────────────────────
    void pinMode(uint32_t pin, uint32_t mode)       override;
    void digitalWrite(uint32_t pin, uint32_t value) override;
    uint32_t digitalRead(uint32_t pin)              override;

    // ── Interrupts ────────────────────────────────────────
    void attachInterrupt(uint32_t pin, void (*func)(void), uint32_t mode) override;
    void detachInterrupt(uint32_t pin)              override;

    // ── Timing ────────────────────────────────────────────
    void delay(RadioLibTime_t ms)                   override;
    void delayMicroseconds(RadioLibTime_t us)       override;
    RadioLibTime_t millis()                         override;
    RadioLibTime_t micros()                         override;

    // ── SPI ───────────────────────────────────────────────
    // Beim STM32WLE5 ist das Radio intern — kein echter SPI-Bus
    // RadioLib ruft diese trotzdem auf; wir leiten auf SUBGHZ-HAL um
    void spiBegin()                                 override;
    void spiBeginTransaction()                      override;
    void spiTransfer(uint8_t* out, size_t len, uint8_t* in) override;
    void spiEndTransaction()                        override;
    void spiEnd()                                   override;

    // ── Virtuelle STM32WL-Pins (RF-Switch via SUBGHZ-HAL) ─
    void setRfSwitchState(bool txEnable, bool rxEnable);

    // ── UART (für Log-Ausgabe) ────────────────────────────
    void uartBegin(uint32_t baud);
    void uartPrint(const char* str);
    void uartPrintf(const char* format, ...);

    // ── Tone (nicht benötigt, leere Implementierung) ──────
    void tone(uint32_t, unsigned int, RadioLibTime_t) override {}
    void noTone(uint32_t)                             override {}

    long pulseIn(uint32_t pin, uint32_t state, RadioLibTime_t timeout) override { (void)pin; (void)state; (void)timeout; return 0; }

private:
    // TX-Buffer für internen SUBGHZ-SPI
    uint8_t _spiTxBuf[256];
    uint8_t _spiRxBuf[256];
    uint16_t _spiBufIdx = 0;
    bool _spiActive = false;
};

// Virtuelle Pin-Konstanten (analog zu RadioLib STM32WLx)
// Übereinstimmend mit STM32WL SUBGHZ-Peripheral-Definitionen
#define RADIOLIB_VIRTUAL_PIN_BASE   0x100
#define VIRTUAL_PIN_TX_EN           (RADIOLIB_VIRTUAL_PIN_BASE + 0)
#define VIRTUAL_PIN_RX_EN           (RADIOLIB_VIRTUAL_PIN_BASE + 1)

#ifndef HIGH
#define HIGH 1
#endif

#ifndef LOW
#define LOW 0
#endif